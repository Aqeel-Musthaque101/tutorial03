package com.aie.intentsproj;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FirstActivity extends AppCompatActivity {
    Button button;
    Toast toast;
    EditText FirstNumber;
    EditText SecondNumber;
    double val1,val2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        OneclickButtonListner();
    }

    public void OneclickButtonListner(){
        FirstNumber = (EditText)findViewById(R.id.FirstNumber);//reading string values to the relevent edit text objects
        SecondNumber = (EditText)findViewById(R.id.SecondNumber);

        button = (Button)findViewById(R.id.button);
        button.setOnClickListener(

            new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    Context context = getApplicationContext();
                    //CharSequence text = "Navigating to activity 2";//the text we want to type in the message,change this to the value calculated as the answer
                    //int duration = Toast.LENGTH_SHORT;//for a short message duration, change this to long when calculation
                    //toast = Toast.makeText(context,text,duration);
                    //toast.setGravity(Gravity.CENTER_VERTICAL, 0,0);//specifieng location of toast
                    //toast.show();//in order to trigger the message

                    //Creating the LayoutInflater instance
                    LayoutInflater li = getLayoutInflater();
                    //Getting the View object as defined in the customtoast.xml file
                    View layout = li.inflate(R.layout.customtoast, (ViewGroup) findViewById(R.id.custom_toast_layout));
                    //Creating the Toast objectToast
                    toast = new Toast(getApplicationContext());
                    toast.setDuration(Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                    toast.setView(layout);
                    //setting the view of custom toast layout
                    toast.show();

                    val1 = Double.valueOf(FirstNumber.getText().toString()); //converting input values to double
                    val2 = Double.valueOf(SecondNumber.getText().toString());

                    Intent cals = new Intent(getApplicationContext(),SecondActivity.class);
                    cals.putExtra("Value1",val1);//sending values from first activity to second
                    cals.putExtra("Value2",val2);
                    startActivity(cals);

                }
            }

        );

    }
}
