package com.aie.intentsproj;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static android.text.TextUtils.concat;

public class SecondActivity extends AppCompatActivity {
    Button add,substract,multiply,divide;
    Toast toast;
    Double value1,value2;
    EditText First;
    EditText Second;
    TextView Result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        OneclickButtonListner();
        Bundle extras = getIntent().getExtras();
        value1 = extras.getDouble("Value1");
        value2 = extras.getDouble("Value2");

        First = findViewById(R.id.First);
        First.setText(Double.toString(value1));

        Second = findViewById(R.id.Second);
        Second.setText(Double.toString(value2));


    }
    public void OneclickButtonListner(){

        Bundle extras = getIntent().getExtras();
        value1 = extras.getDouble("Value1");
        value2 = extras.getDouble("Value2");

        add = (Button)findViewById(R.id.add);
        add.setOnClickListener(

                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Double result= value1+value2 ;
                        TextView Result = (TextView) findViewById(R.id.Res);
                        Result.setText(Double.toString(value1) + " + " + Double.toString(value2) + " = " + Double.toString(result) );

                    }
                }

        );
        substract = (Button)findViewById(R.id.substract);
        substract.setOnClickListener(

                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Double result= value1-value2 ;
                        TextView Result = (TextView)findViewById(R.id.Res);
                        Result.setText(Double.toString(value1) + " - " + Double.toString(value2) + " = " + Double.toString(result) );

                    }
                }

        );

        multiply = (Button)findViewById(R.id.multiply);
        multiply.setOnClickListener(

                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Double result= value1*value2 ;
                        TextView Result = (TextView)findViewById(R.id.Res);
                        Result.setText(Double.toString(value1) + " * " + Double.toString(value2) + " = " + Double.toString(result) );

                    }
                }

        );

        divide = (Button)findViewById(R.id.divide);
        divide.setOnClickListener(

                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Double result= value1/value2 ;
                        TextView Result = (TextView)findViewById(R.id.Res);
                        Result.setText(Double.toString(value1) + " / " + Double.toString(value2) + " = " + Double.toString(result) );


                    }
                }

        );
    }

}
